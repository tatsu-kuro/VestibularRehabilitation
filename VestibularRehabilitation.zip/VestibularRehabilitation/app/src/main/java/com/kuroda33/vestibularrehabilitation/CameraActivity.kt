package com.kuroda33.vestibularrehabilitation
import android.Manifest
import android.annotation.TargetApi
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.*
import android.hardware.camera2.*
import android.media.ImageReader
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.HandlerThread
import android.support.annotation.RequiresApi
import android.support.v4.app.ActivityCompat
import android.support.v4.content.ContextCompat
import android.support.v7.app.AlertDialog
import android.support.v7.app.AppCompatActivity
import android.util.Log
import android.util.Size
import android.view.Surface
import android.view.TextureView
import java.util.*
import android.hardware.camera2.CameraAccessException
import android.widget.Toast
import android.hardware.camera2.CameraCaptureSession
import java.util.Arrays.asList
import android.hardware.camera2.CameraDevice
import android.opengl.ETC1.getHeight
import android.opengl.ETC1.getWidth
import android.view.SurfaceHolder
import android.view.WindowManager
import kotlinx.android.synthetic.main.activity_camera.*
import kotlin.math.sin

@TargetApi(Build.VERSION_CODES.LOLLIPOP)
class CameraActivity : AppCompatActivity() , ActivityCompat.OnRequestPermissionsResultCallback, SurfaceHolder.Callback{
    var ww:Int=0
    var wh:Int=0
    var furi:Int=1
    private var mTimer: Timer? = null
    val paintred: Paint = Paint()
    private var mHandler = Handler()
    var KeepScreenOn:Boolean=true
    private lateinit var textureView: TextureView
    private var captureSession: CameraCaptureSession? = null
    private var cameraDevice: CameraDevice? = null
    private val previewSize: Size = Size(300, 300) // FIXME: for now.
    private lateinit var previewRequestBuilder: CaptureRequest.Builder
    private var imageReader: ImageReader? = null
    private lateinit var previewRequest: CaptureRequest
    private var backgroundThread: HandlerThread? = null
    private var backgroundHandler: Handler? = null
 //   var cnt1:Int=0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_camera)
 //       textureView = findViewById(R.id.mySurfaceView)
 //       textureView.surfaceTextureListener = surfaceTextureListener;
  //      startBackgroundThread()
        paintred.isAntiAlias = false
        paintred.style = Paint.Style.FILL
        paintred.color = Color.RED
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        mTimer = Timer()
        KeepScreenOn=true
        // タイマーの始動
        var holder = surfaceView.holder
        holder.addCallback(this)
        holder.setFormat(PixelFormat.TRANSLUCENT)
        val time0=System.currentTimeMillis()
        Log.d("CANVASstart","start")
        mTimer!!.schedule(object : TimerTask() {
            override fun run() {
                val temp=System.currentTimeMillis()-time0
                drawCanvas(temp)
                if(temp>1000*60*10&&KeepScreenOn){//10min
                    KeepScreenOn=false
                    mHandler.post{
                        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                    }
                }
            }
        }, 100, 16)
 //       surfaceView.alpha=0.5f
        textureView = findViewById(R.id.mySurfaceView)
        textureView.surfaceTextureListener = surfaceTextureListener;
        startBackgroundThread()
        textureView.alpha=.5f
    }
    private fun drawCanvas(tt:Long) {
        val canvas = surfaceView.holder.lockCanvas()
        if(ww==0||canvas==null)return
//        canvas.drawColor(Color.WHITE)
        canvas.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR);
        if(furi==1) {
            canvas.drawCircle(ww.toFloat()/2f+(ww*9/20).toFloat()* sin(3.1415f*tt.toFloat()/1666),wh.toFloat()/2f,(ww/50).toFloat(),paintred)
        }else{
            canvas.drawCircle(ww.toFloat()/2f+(ww*6/20).toFloat()* sin(3.1415f*tt.toFloat()/1666),wh.toFloat()/2f,(ww/50).toFloat(),paintred)
        }
        //     Log.d("CANVAS:",tt.toString())
        surfaceView.holder.unlockCanvasAndPost(canvas)
    }
    fun openCamera(width:Int,height:Int) {
        var manager: CameraManager = getSystemService(Context.CAMERA_SERVICE) as CameraManager

        try {
            var camerId: String = manager.getCameraIdList()[0]
            val permission = ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)

            if (permission != PackageManager.PERMISSION_GRANTED) {
                requestCameraPermission()
                return
            }
            manager.openCamera(camerId, stateCallback, null);
            configureTransform(width, height)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
    override fun surfaceChanged(holder: SurfaceHolder?, format: Int, width: Int, height: Int) {
        //       surfaceWidth = width
        //       surfaceHeight = height
        ww=width
        wh=height
    }
    override fun onDestroy() {
        super.onDestroy()
        if (mTimer != null){
            mTimer!!.cancel()
            mTimer = null
        }
        if(cameraDevice != null){
            cameraDevice = null

            backgroundHandler=null
        }
    }
    override fun surfaceDestroyed(holder: SurfaceHolder?) {
    }

    override fun surfaceCreated(holder: SurfaceHolder?) {
    }
    private val stateCallback = object : CameraDevice.StateCallback() {

        override fun onOpened(cameraDevice: CameraDevice) {
            this@CameraActivity.cameraDevice = cameraDevice
            createCameraPreviewSession()
        }

        override fun onDisconnected(cameraDevice: CameraDevice) {
            cameraDevice.close()
            this@CameraActivity.cameraDevice = null
        }

        override fun onError(cameraDevice: CameraDevice, error: Int) {
            onDisconnected(cameraDevice)
            finish()
        }
    }

    private fun createCameraPreviewSession() {
        try {
            val texture = textureView.surfaceTexture
            texture.setDefaultBufferSize(previewSize.width, previewSize.height)
            val surface = Surface(texture)
            previewRequestBuilder = cameraDevice!!.createCaptureRequest(
                CameraDevice.TEMPLATE_PREVIEW
            )
            previewRequestBuilder.addTarget(surface)
            cameraDevice?.createCaptureSession(Arrays.asList(surface, imageReader?.surface),
                @RequiresApi(Build.VERSION_CODES.LOLLIPOP)
                object : CameraCaptureSession.StateCallback() {

                    override fun onConfigured(cameraCaptureSession: CameraCaptureSession) {

                        if (cameraDevice == null) return
                        captureSession = cameraCaptureSession
                        try {
                            previewRequestBuilder.set(CaptureRequest.CONTROL_AF_MODE,
                                CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE)
                            previewRequest = previewRequestBuilder.build()
                            captureSession?.setRepeatingRequest(previewRequest,
                                null, Handler(backgroundThread?.looper))
                        } catch (e: CameraAccessException) {
                            Log.e("erfs", e.toString())
                        }

                    }

                    override fun onConfigureFailed(session: CameraCaptureSession) {
                        //Tools.makeToast(baseContext, "Failed")
                    }
                }, null)
        } catch (e: CameraAccessException) {
            Log.e("erf", e.toString())
        }

    }

    @TargetApi(Build.VERSION_CODES.M)
    fun requestCameraPermission() {
        if (shouldShowRequestPermissionRationale(Manifest.permission.CAMERA)) {
            AlertDialog.Builder(baseContext)
                .setMessage("Permission Here")
                .setPositiveButton(android.R.string.ok) { _, _ ->
                    requestPermissions(arrayOf(Manifest.permission.CAMERA),
                        200)
                }
                .setNegativeButton(android.R.string.cancel) { _, _ ->
                    finish()
                }
                .create()
        } else {
            requestPermissions(arrayOf(Manifest.permission.CAMERA), 200)
        }
    }

    private fun configureTransform(viewWidth: Int, viewHeight: Int) {

        val windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val rotation = windowManager.defaultDisplay.rotation
        //       activity ?: return
        //       val rotation = activity.windowManager.defaultDisplay.rotation
        val matrix = Matrix()
        val viewRect = RectF(0f, 0f, viewWidth.toFloat(), viewHeight.toFloat())
        val bufferRect = RectF(0f, 0f, previewSize.height.toFloat(), previewSize.width.toFloat())
        val centerX = viewRect.centerX()
        val centerY = viewRect.centerY()

        if (Surface.ROTATION_90 == rotation || Surface.ROTATION_270 == rotation) {
            bufferRect.offset(centerX - bufferRect.centerX(), centerY - bufferRect.centerY())
            val scale = Math.max(
                viewHeight.toFloat() / previewSize.height,
                viewWidth.toFloat() / previewSize.width)
            with(matrix) {
                setRectToRect(viewRect, bufferRect, Matrix.ScaleToFit.FILL)
                postScale(scale, scale, centerX, centerY)
                postRotate((90 * (rotation - 2)).toFloat(), centerX, centerY)
            }
        } else if (Surface.ROTATION_180 == rotation) {
            matrix.postRotate(180f, centerX, centerY)
        }
        textureView.setTransform(matrix)
    }

    private fun startBackgroundThread() {
        backgroundThread = HandlerThread("CameraBackground").also { it.start() }
        backgroundHandler = Handler(backgroundThread?.looper)
    }


    private val surfaceTextureListener = object : TextureView.SurfaceTextureListener {

        override fun onSurfaceTextureAvailable(surface: SurfaceTexture, width: Int, height: Int) {
            imageReader = ImageReader.newInstance(width,height,
                ImageFormat.JPEG, /*maxImages*/ 2);
            openCamera(width,height)
        }

        override fun onSurfaceTextureSizeChanged(p0: SurfaceTexture?, p1: Int, p2: Int) {
            //          configureTransform(p1,p2)
     //       cnt1 += 1
       //     Log.e("UPDATE:", cnt1.toString())
        }

        override fun onSurfaceTextureUpdated(p0: SurfaceTexture?) {
         //   cnt1 += 1
           // Log.e("UPDATE:", cnt1.toString())
        }

        override fun onSurfaceTextureDestroyed(p0: SurfaceTexture?): Boolean {
            return false
        }
    }
}
