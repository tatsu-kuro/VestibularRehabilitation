package com.kuroda33.vestibularrehabilitation

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() , View.OnClickListener{

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        mini13.setOnClickListener(this)
        mini15.setOnClickListener(this)
        mini110.setOnClickListener(this)
        mini23.setOnClickListener(this)
        mini25.setOnClickListener(this)
        mini210.setOnClickListener(this)
        mini33.setOnClickListener(this)
        mini35.setOnClickListener(this)
        mini310.setOnClickListener(this)
    }
    override fun onClick(v: View) {
        when(v.id){
            R.id.mini13 -> mini13()
            R.id.mini15 -> mini15()
            R.id.mini110 -> mini110()
            R.id.mini23 -> mini23()
            R.id.mini25 -> mini25()
            R.id.mini210 -> mini210()
            R.id.mini33 -> mini33()
            R.id.mini35 -> mini35()
            R.id.mini310 -> mini310()
        }
    }
    private fun mini13(){
       // Log.d("mini:", String.format("%d %d", 1, 3))
        val intent= Intent(this,SecondActivity::class.java)
        startActivity(intent)
    }
    private fun mini15(){
    //    Log.d("mini:", String.format("%d %d", 1, 5))
        val intent= Intent(this,CameraActivity::class.java)
        startActivity(intent)
    }
    private fun mini110(){

    }
    private fun mini23(){

    }
    private fun mini25(){

    }
    private fun mini210(){

    }
    private fun mini33(){

    }
    private fun mini35(){

    }
    private fun mini310(){

    }
}
