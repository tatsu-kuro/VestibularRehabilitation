package com.kuroda33.vestibularrehabilitation

import android.graphics.Color
import android.graphics.Paint
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.support.v4.app.ActivityCompat
import android.util.Log
import android.view.SurfaceHolder
import android.view.TextureView
import android.view.WindowManager
import kotlinx.android.synthetic.main.activity_second.*
import java.util.*
import kotlin.math.sin

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.*
import android.hardware.camera2.*
import android.media.ImageReader
import android.os.Build

import android.os.HandlerThread
import android.support.annotation.RequiresApi
import android.support.v4.content.ContextCompat
import android.support.v7.app.AlertDialog
import android.util.Size
import android.view.Surface
import java.util.*
import android.hardware.camera2.CameraAccessException
import android.widget.Toast
import android.hardware.camera2.CameraCaptureSession
import java.util.Arrays.asList
import android.hardware.camera2.CameraDevice
//import android.opengl.ETC1.getHeight
//import android.opengl.ETC1.getWidth



class SecondActivity : AppCompatActivity() , SurfaceHolder.Callback , ActivityCompat.OnRequestPermissionsResultCallback{
    var ww:Int=0
    var wh:Int=0
    var furi:Int=1
    private var mTimer: Timer? = null
    val paintred: Paint = Paint()

    private var mHandler = Handler()
    var KeepScreenOn:Boolean=true
    private lateinit var textureView: TextureView

    private var captureSession: CameraCaptureSession? = null
    private var cameraDevice: CameraDevice? = null
    private lateinit var previewRequestBuilder: CaptureRequest.Builder
    private var imageReader: ImageReader? = null
    private lateinit var previewRequest: CaptureRequest
    private var backgroundThread: HandlerThread? = null
    private var backgroundHandler: Handler? = null



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second)

        paintred.isAntiAlias = false
        paintred.style = Paint.Style.FILL
        paintred.color = Color.RED
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        mTimer = Timer()
        KeepScreenOn=true
        // タイマーの始動
        var holder = surfaceView.holder
        holder.addCallback(this)
        val time0=System.currentTimeMillis()
        Log.d("CANVASstart","start")
        mTimer!!.schedule(object : TimerTask() {
            override fun run() {
                val temp=System.currentTimeMillis()-time0
                drawCanvas(temp)
                if(temp>1000*60*10&&KeepScreenOn){//10min
                    KeepScreenOn=false
                    mHandler.post{
                        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                    }
                }
            }
        }, 100, 16)    }
    override fun surfaceChanged(holder: SurfaceHolder?, format: Int, width: Int, height: Int) {
        //       surfaceWidth = width
        //       surfaceHeight = height
        ww=width
        wh=height
    }
    override fun surfaceDestroyed(holder: SurfaceHolder?) {
    }

    override fun surfaceCreated(holder: SurfaceHolder?) {
    }
    private fun drawCanvas(tt:Long) {
        val canvas = surfaceView.holder.lockCanvas()
        if(ww==0||canvas==null)return
        canvas.drawColor(Color.WHITE)
        if(furi==1) {
            canvas.drawCircle(ww.toFloat()/2f+(ww*9/20).toFloat()* sin(3.1415f*tt.toFloat()/1666),wh.toFloat()/2f,(ww/50).toFloat(),paintred)

        }else{
            canvas.drawCircle(ww.toFloat()/2f+(ww*6/20).toFloat()* sin(3.1415f*tt.toFloat()/1666),wh.toFloat()/2f,(ww/50).toFloat(),paintred)

        }
        //     Log.d("CANVAS:",tt.toString())
        surfaceView.holder.unlockCanvasAndPost(canvas)
    }
}
